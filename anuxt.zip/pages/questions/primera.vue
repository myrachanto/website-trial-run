<template>
  <div class="quizsect">
    <div class="quizgrid">
    <div class="quizinner">
      <div class="quiztopic"> The question</div>
      <div class="quizbody">We design and develop websites or application to accomodate both personal or business related. Our goal is to ensure that you as a client get to reap all the benefits associated with the product in this case website or web application that you hired us to develop. Online Accounting applications, e-commerce websites, simple websites, are just but a few of what we do here at Chantosweb developersWe design and develop websites or application to accomodate both personal or business related. Our goal is to ensure that you as a client get to reap all the benefits associated with the product in this case website or web application that you hired us to develop. Online Accounting applications, e-commerce websites, simple websites, are just but a few of what we do here at Chantosweb developersWe design and develop websites or application to accomodate both personal or business related. Our goal is to ensure that you as a client get to reap all the benefits associated with the product in this case website or web application that you hired us to develop. Online Accounting applications, e-commerce websites, simple websites, are just but a few of what we do here at Chantosweb developersWe design and develop websites or application to accomodate both personal or business related. Our goal is to ensure that you as a client get to reap all the benefits associated with the product in this case website or web application that you hired us to develop. Online Accounting applications, e-commerce websites, simple websites, are just but a few of what we do here at Chantosweb developersWe design and develop websites or application to accomodate both personal or business related. Our goal is to ensure that you as a client get to reap all the benefits associated with the product in this case website or web application that you hired us to develop. Online Accounting applications, e-commerce websites, simple websites, are just but a few of what we do here at Chantosweb developersWe design and develop websites or application to accomodate both personal or business related. Our goal is to ensure that you as a client get to reap all the benefits associated with the product in this case website or web application that you hired us to develop. Online Accounting applications, e-commerce websites, simple websites, are just but a few of what we do here at Chantosweb developersWe design and develop websites or application to accomodate both personal or business related. Our goal is to ensure that you as a client get to reap all the benefits associated with the product in this case website or web application that you hired us to develop. Online Accounting applications, e-commerce websites, simple websites, are just but a few of what we do here at Chantosweb developersWe design and develop websites or application to accomodate both personal or business related. Our goal is to ensure that you as a client get to reap all the benefits associated with the product in this case website or web application that you hired us to develop. Online Accounting applications, e-commerce websites, simple websites, are just but a few of what we do here at Chantosweb developers

      </div>
    <div class="quizorder1">Our experts have answered this question before</div>
    <div class="quizorder2">Order your fresh answer as we don't resell customers answers to avoid plagiarism</div>
    <a :href="`https://app.topresearchpapers.com/signup`"><div class="quizorder3">Order your customized answer written from scracth now</div></a>
    <div class="quizfoot">
          <a :href="`https://app.topresearchpapers.com/signup`"><button class="quizbtn">
            order now
          </button></a>
      </div>
    </div>
    <div class="quizcal">
      <contactform />
      <freeitems />
    </div>
    </div>
  </div>
</template>

<script>
import contactform from '~/components/component/contactform.vue'
import Freeitems from '~/components/component/freeitems.vue'
export default {
  components: { contactform, Freeitems },
head () {
    return {
      title: 'quiz',
      meta: [
        { hid: 'description', name: 'description', content: 'quiz' },
        { hid: 'og:title', name: 'og:title', content: 'quiz' },
        { hid: 'og:description', name: 'og:description', content: 'quiz' },
        { hid: 'og:type', name: 'og:type', content: 'website' },
        { hid: 'og:url', name: 'og:url', content: `https://essaymentor.us` },
      ]
    }
  },
}
</script>

<style>
.quizsect{
  @apply mt-16 container mx-auto ;
}
.quizgrid{
  @apply grid grid-cols-1 lg:grid-cols-3;
}
.quizinner{
  @apply px-5 col-span-2;
}
.quizcal{
  @apply py-10;
}
.quiztopic{
  @apply my-8 pt-4 text-2xl md:text-3xl;
}
.quizbody {
  @apply text-xl;
}
.quizfoot{
  @apply flex justify-center items-center;
}
.quizbtn{
  @apply bg-blue-800 text-white text-lg mx-auto lg:mx-0 hover:underline text-white font-bold rounded-full my-6 py-4 px-8 focus:outline-none ;
}
.quizorder1{
  @apply text-2xl flex justify-center items-center text-blue-800;
}
.quizorder2{
  @apply text-2xl flex justify-center items-center text-blue-800;
}
.quizorder3{
  @apply text-2xl flex justify-center items-center text-white bg-blue-800 rounded-full;
}
</style>