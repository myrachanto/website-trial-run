# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<Logo>` | `<logo>` (components/Logo.vue)
- `<LayoutsFootercard>` | `<layouts-footercard>` (components/layouts/Footercard.vue)
- `<LayoutsFooting>` | `<layouts-footing>` (components/layouts/Footing.vue)
- `<LayoutsModal>` | `<layouts-modal>` (components/layouts/modal.vue)
- `<LayoutsNavbar>` | `<layouts-navbar>` (components/layouts/Navbar.vue)
- `<ComponentAsection>` | `<component-asection>` (components/component/asection.vue)
- `<ComponentAsection2>` | `<component-asection2>` (components/component/asection2.vue)
- `<ComponentBlurry>` | `<component-blurry>` (components/component/blurry.vue)
- `<ComponentCardi>` | `<component-cardi>` (components/component/cardi.vue)
- `<ComponentContactform>` | `<component-contactform>` (components/component/contactform.vue)
- `<ComponentFreeitems>` | `<component-freeitems>` (components/component/freeitems.vue)
- `<ComponentQuestion>` | `<component-question>` (components/component/question.vue)
- `<ComponentRatings>` | `<component-ratings>` (components/component/ratings.vue)
- `<ComponentSection3>` | `<component-section3>` (components/component/section3.vue)
