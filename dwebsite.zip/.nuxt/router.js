import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _040ad642 = () => interopDefault(import('..\\pages\\aboutus.vue' /* webpackChunkName: "pages/aboutus" */))
const _30406c1e = () => interopDefault(import('..\\pages\\questions\\index.vue' /* webpackChunkName: "pages/questions/index" */))
const _a171558c = () => interopDefault(import('..\\pages\\questions\\primera.vue' /* webpackChunkName: "pages/questions/primera" */))
const _c38701d8 = () => interopDefault(import('..\\pages\\questions\\_url.vue' /* webpackChunkName: "pages/questions/_url" */))
const _76b4b469 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/aboutus",
    component: _040ad642,
    name: "aboutus"
  }, {
    path: "/questions",
    component: _30406c1e,
    name: "questions"
  }, {
    path: "/questions/primera",
    component: _a171558c,
    name: "questions-primera"
  }, {
    path: "/questions/:url",
    component: _c38701d8,
    name: "questions-url"
  }, {
    path: "/",
    component: _76b4b469,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config.app && config.app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
