export { default as Logo } from '../..\\components\\Logo.vue'
export { default as ComponentAsection } from '../..\\components\\component\\asection.vue'
export { default as ComponentAsection2 } from '../..\\components\\component\\asection2.vue'
export { default as ComponentBlurry } from '../..\\components\\component\\blurry.vue'
export { default as ComponentCardi } from '../..\\components\\component\\cardi.vue'
export { default as ComponentContactform } from '../..\\components\\component\\contactform.vue'
export { default as ComponentFreeitems } from '../..\\components\\component\\freeitems.vue'
export { default as ComponentQuestion } from '../..\\components\\component\\question.vue'
export { default as ComponentRatings } from '../..\\components\\component\\ratings.vue'
export { default as ComponentSection3 } from '../..\\components\\component\\section3.vue'
export { default as LayoutsFootercard } from '../..\\components\\layouts\\Footercard.vue'
export { default as LayoutsFooting } from '../..\\components\\layouts\\Footing.vue'
export { default as LayoutsModal } from '../..\\components\\layouts\\modal.vue'
export { default as LayoutsNavbar } from '../..\\components\\layouts\\Navbar.vue'

export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c))
export const LazyComponentAsection = import('../..\\components\\component\\asection.vue' /* webpackChunkName: "components/component-asection" */).then(c => wrapFunctional(c.default || c))
export const LazyComponentAsection2 = import('../..\\components\\component\\asection2.vue' /* webpackChunkName: "components/component-asection2" */).then(c => wrapFunctional(c.default || c))
export const LazyComponentBlurry = import('../..\\components\\component\\blurry.vue' /* webpackChunkName: "components/component-blurry" */).then(c => wrapFunctional(c.default || c))
export const LazyComponentCardi = import('../..\\components\\component\\cardi.vue' /* webpackChunkName: "components/component-cardi" */).then(c => wrapFunctional(c.default || c))
export const LazyComponentContactform = import('../..\\components\\component\\contactform.vue' /* webpackChunkName: "components/component-contactform" */).then(c => wrapFunctional(c.default || c))
export const LazyComponentFreeitems = import('../..\\components\\component\\freeitems.vue' /* webpackChunkName: "components/component-freeitems" */).then(c => wrapFunctional(c.default || c))
export const LazyComponentQuestion = import('../..\\components\\component\\question.vue' /* webpackChunkName: "components/component-question" */).then(c => wrapFunctional(c.default || c))
export const LazyComponentRatings = import('../..\\components\\component\\ratings.vue' /* webpackChunkName: "components/component-ratings" */).then(c => wrapFunctional(c.default || c))
export const LazyComponentSection3 = import('../..\\components\\component\\section3.vue' /* webpackChunkName: "components/component-section3" */).then(c => wrapFunctional(c.default || c))
export const LazyLayoutsFootercard = import('../..\\components\\layouts\\Footercard.vue' /* webpackChunkName: "components/layouts-footercard" */).then(c => wrapFunctional(c.default || c))
export const LazyLayoutsFooting = import('../..\\components\\layouts\\Footing.vue' /* webpackChunkName: "components/layouts-footing" */).then(c => wrapFunctional(c.default || c))
export const LazyLayoutsModal = import('../..\\components\\layouts\\modal.vue' /* webpackChunkName: "components/layouts-modal" */).then(c => wrapFunctional(c.default || c))
export const LazyLayoutsNavbar = import('../..\\components\\layouts\\Navbar.vue' /* webpackChunkName: "components/layouts-navbar" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
export function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
