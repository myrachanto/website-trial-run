import Vue from 'vue'
import { wrapFunctional } from './index'

const components = {
  Logo: () => import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => wrapFunctional(c.default || c)),
  ComponentAsection: () => import('../..\\components\\component\\asection.vue' /* webpackChunkName: "components/component-asection" */).then(c => wrapFunctional(c.default || c)),
  ComponentAsection2: () => import('../..\\components\\component\\asection2.vue' /* webpackChunkName: "components/component-asection2" */).then(c => wrapFunctional(c.default || c)),
  ComponentCardi: () => import('../..\\components\\component\\cardi.vue' /* webpackChunkName: "components/component-cardi" */).then(c => wrapFunctional(c.default || c)),
  ComponentContactform: () => import('../..\\components\\component\\contactform.vue' /* webpackChunkName: "components/component-contactform" */).then(c => wrapFunctional(c.default || c)),
  ComponentFreeitems: () => import('../..\\components\\component\\freeitems.vue' /* webpackChunkName: "components/component-freeitems" */).then(c => wrapFunctional(c.default || c)),
  ComponentQuestion: () => import('../..\\components\\component\\question.vue' /* webpackChunkName: "components/component-question" */).then(c => wrapFunctional(c.default || c)),
  ComponentSection3: () => import('../..\\components\\component\\section3.vue' /* webpackChunkName: "components/component-section3" */).then(c => wrapFunctional(c.default || c)),
  LayoutsFootercard: () => import('../..\\components\\layouts\\Footercard.vue' /* webpackChunkName: "components/layouts-footercard" */).then(c => wrapFunctional(c.default || c)),
  LayoutsFooting: () => import('../..\\components\\layouts\\Footing.vue' /* webpackChunkName: "components/layouts-footing" */).then(c => wrapFunctional(c.default || c)),
  LayoutsNavbar: () => import('../..\\components\\layouts\\Navbar.vue' /* webpackChunkName: "components/layouts-navbar" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
