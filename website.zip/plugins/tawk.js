import Vue from 'vue';
import Tawk from 'vue-tawk';

Vue.use(Tawk, {
    tawkSrc: 'https://embed.tawk.to/5b3caa196d961556373d65e7/default'
})